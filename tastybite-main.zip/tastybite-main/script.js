// ---------- Add to Cart Functionality -----------
document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll(".add-to-cart");

  addButtons.forEach(button => {
    button.addEventListener("click", () => {
      const foodCard = button.parentElement;
      const name = foodCard.querySelector("h3").innerText;
      const priceText = foodCard.querySelector(".price").innerText.trim();
       document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll(".add-to-cart");

  addButtons.forEach(button => {
    button.addEventListener("click", () => {
      const foodCard = button.parentElement;
      const name = foodCard.querySelector("h3").innerText;
      const priceText = foodCard.querySelector(".price").innerText.trim();
      const price = parseInt(priceText.replace("₹", ""));
      const img = foodCard.querySelector("img").src;

      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      const existing = cart.find(item => item.name === name);

      if (existing) existing.quantity += 1;
      else cart.push({ name, price, img, quantity: 1 });

      localStorage.setItem("cart", JSON.stringify(cart));
      displayCart(cart); // Update table immediately
      alert(`${name} added to cart!`);
    });
  });

  // Load cart table on page load
  displayCart(JSON.parse(localStorage.getItem("cart")) || []);
});

function displayCart(cart) {
  const cartBody = document.getElementById("cart-body");
  const cartTotal = document.getElementById("cart-total");

  if (!cartBody || !cartTotal) return;

  cartBody.innerHTML = "";
  let totalAmount = 0;

  cart.forEach((item, index) => {
    const total = item.price * item.quantity;
    totalAmount += total;

    const row = document.createElement("tr");
    row.innerHTML = `
      <td><img src="${item.img}" class="cart-img"></td>
      <td>${item.name}</td>
      <td>₹${item.price}</td>
      <td>
        <button class="qty-btn" onclick="updateQty(${index}, -1)">−</button>
        ${item.quantity}
        <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
      </td>
      <td>₹${total}</td>
      <td><button class="remove-btn" onclick="removeItem(${index})">Remove</button></td>
    `;
    cartBody.appendChild(row);
  });

  cartTotal.innerText = cart.length > 0 ? `Grand Total: ₹${totalAmount}` : "Your cart is empty.";
}
const price = parseInt(priceText.replace("₹", ""));

      const img = foodCard.querySelector("img").src;

      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      const existing = cart.find(item => item.name === name);

      if (existing) {
        existing.quantity += 1;
      } else {
        cart.push({ name, price, img, quantity: 1 });
      }

      localStorage.setItem("cart", JSON.stringify(cart));
      alert(`${name} added to cart!`);
    });
  });

  // ---------- Load Cart Table -----------
  const cartBody = document.getElementById("cart-body");
  if (cartBody) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    displayCart(cart);
  }
});

function displayCart(cart) {
  const cartBody = document.getElementById("cart-body");
  const cartTotal = document.getElementById("cart-total");

  if (!cartBody) return;

  cartBody.innerHTML = "";
  let totalAmount = 0;

  cart.forEach((item, index) => {
    const total = item.price * item.quantity;
    totalAmount += total;

    const row = document.createElement("tr");
    row.innerHTML = `
      <td><img src="${item.img}" class="cart-img"></td>
      <td>${item.name}</td>
      <td>₹${item.price}</td>
      <td>
        <button class="qty-btn" onclick="updateQty(${index}, -1)">−</button>
        ${item.quantity}
        <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
      </td>
      <td>₹${total}</td>
      <td><button class="remove-btn" onclick="removeItem(${index})">Remove</button></td>
    `;
    cartBody.appendChild(row);
  });

  cartTotal.innerText = cart.length > 0 ? `Grand Total: ₹${totalAmount}` : "Your cart is empty.";
}

function updateQty(index, change) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart[index].quantity += change;
  if (cart[index].quantity <= 0) cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  displayCart(cart);
}

function removeItem(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  displayCart(cart);
}
